<?php
namespace MailPoetVendor\Twig\Error;
if (!defined('ABSPATH')) exit;
class LoaderError extends Error
{
}
