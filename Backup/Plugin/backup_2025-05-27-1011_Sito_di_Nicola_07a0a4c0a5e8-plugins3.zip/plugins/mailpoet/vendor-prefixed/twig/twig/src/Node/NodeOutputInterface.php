<?php
namespace MailPoetVendor\Twig\Node;
if (!defined('ABSPATH')) exit;
interface NodeOutputInterface
{
}
