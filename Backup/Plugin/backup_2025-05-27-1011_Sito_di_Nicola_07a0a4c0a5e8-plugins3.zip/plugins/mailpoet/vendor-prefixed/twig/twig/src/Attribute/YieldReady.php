<?php
namespace MailPoetVendor\Twig\Attribute;
if (!defined('ABSPATH')) exit;
#[\Attribute(\Attribute::TARGET_CLASS)]
final class YieldReady
{
}
