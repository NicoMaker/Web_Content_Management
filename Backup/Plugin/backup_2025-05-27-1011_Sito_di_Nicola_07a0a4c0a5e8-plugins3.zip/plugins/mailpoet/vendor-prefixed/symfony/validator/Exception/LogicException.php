<?php
namespace MailPoetVendor\Symfony\Component\Validator\Exception;
if (!defined('ABSPATH')) exit;
class LogicException extends \LogicException implements ExceptionInterface
{
}
