<?php
namespace MailPoetVendor\Symfony\Component\Validator\Exception;
if (!defined('ABSPATH')) exit;
class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
