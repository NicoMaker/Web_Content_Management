<?php
namespace MailPoetVendor\Symfony\Component\Validator\Mapping;
if (!defined('ABSPATH')) exit;
final class AutoMappingStrategy
{
 public const NONE = 0;
 public const ENABLED = 1;
 public const DISABLED = 2;
 private function __construct()
 {
 }
}
