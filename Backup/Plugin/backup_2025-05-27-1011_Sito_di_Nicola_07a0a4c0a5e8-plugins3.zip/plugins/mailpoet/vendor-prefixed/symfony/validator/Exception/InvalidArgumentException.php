<?php
namespace MailPoetVendor\Symfony\Component\Validator\Exception;
if (!defined('ABSPATH')) exit;
class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
