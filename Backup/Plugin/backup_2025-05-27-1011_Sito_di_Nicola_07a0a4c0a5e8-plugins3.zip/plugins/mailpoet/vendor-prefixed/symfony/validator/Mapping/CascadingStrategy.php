<?php
namespace MailPoetVendor\Symfony\Component\Validator\Mapping;
if (!defined('ABSPATH')) exit;
class CascadingStrategy
{
 public const NONE = 1;
 public const CASCADE = 2;
 private function __construct()
 {
 }
}
