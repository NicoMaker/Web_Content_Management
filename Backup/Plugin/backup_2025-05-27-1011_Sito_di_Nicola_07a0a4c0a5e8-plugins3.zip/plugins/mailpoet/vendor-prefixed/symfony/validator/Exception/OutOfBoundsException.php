<?php
namespace MailPoetVendor\Symfony\Component\Validator\Exception;
if (!defined('ABSPATH')) exit;
class OutOfBoundsException extends \OutOfBoundsException implements ExceptionInterface
{
}
