<?php
namespace MailPoetVendor\Symfony\Component\Validator\Exception;
if (!defined('ABSPATH')) exit;
class NoSuchMetadataException extends ValidatorException
{
}
