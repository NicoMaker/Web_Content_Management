<?php
// phpcs:ignoreFile
// Silence is golden.
